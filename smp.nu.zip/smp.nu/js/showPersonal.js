function showPersonal(shortname) {
    window.location.href = window.location.href.toString() + "?emp=" + shortname;
}